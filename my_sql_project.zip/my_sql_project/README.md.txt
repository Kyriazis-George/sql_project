# my_sql_project



## Περιεχόμενα

- 📁 schema/create_tables.sql
- 📁 data/insert_data.sql 
- 📁 queries/select_examples.sql

## Πίνακες

- **Customers**
- **Products**
- **Orders**

## Τεχνολογίες

- SQL (MySQL / SQLite / PostgreSQL)